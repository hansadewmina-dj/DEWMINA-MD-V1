//#ENJOY
const fs = require("fs-extra");
if (fs.existsSync(".env"))
  require("dotenv").config({ path: __dirname + "/.env" });
global.audio = "";
global.video = "";
global.port = process.env.PORT;
global.appUrl = process.env.APP_URL || "";
global.email = "hansadewmina4@gmail.com";
global.location = "Sri Lanka";
global.mongodb = process.env.MONGODB_URI || "";
global.allowJids = process.env.ALLOW_JID || "null";
global.blockJids = process.env.BLOCK_JID || "null";
global.DATABASE_URL = process.env.DATABASE_URL || "";
global.timezone = process.env.TZ || process.env.TIME_ZONE || "Africa/Lagos";
global.github = process.env.GITHUB || "https://github.com/DeeCeeXxx/Queen_Anita-V2";
global.gurl = process.env.GURL || "https://whatsapp.com/channel/0029VaeRru3ADTOEKPCPom0L";
global.website = process.env.GURL || "https://whatsapp.com/channel/0029VaeRru3ADTOEKPCPom0L";
global.THUMB_IMAGE = process.env.THUMB_IMAGE || process.env.IMAGE || "https://telegra.ph/file/17c8ba84a7761eed633f6.jpg";
global.devs = "https://t.me/deecee_x";
global.sudo = process.env.SUDO || "";
global.owner = process.env.OWNER_NUMBER || "94701515609";
global.style = process.env.STYLE || "3";
global.gdbye = process.env.GOODBYE || "true";
global.wlcm = process.env.WELCOME || "true";
global.warncount = process.env.WARN_COUNT || 3;
global.disablepm = process.env.DISABLE_PM || "false";
global.disablegroup = process.env.DISABLE_GROUPS || "false",
global.MsgsInLog = process.env.MSGS_IN_LOG || "true";
global.userImages = process.env.USER_IMAGES || "https://i.imgur.com/H4qeXwa.jpeg,https://telegra.ph/file/ba9ced500f9eca7db8acb.mp4";
global.waPresence = process.env.WAPRESENCE || "available";
global.readcmds = process.env.READ_COMMAND || "false";
global.readmessage = process.env.READ_MESSAGE || "false";
global.readmessagefrom = process.env.READ_MESSAGE_FROM || "";
global.read_status = process.env.AUTO_READ_STATUS || "true";
global.save_status = process.env.AUTO_SAVE_STATUS || "true";
global.save_status_from = process.env.SAVE_STATUS_FROM || "";
global.read_status_from = process.env.READ_STATUS_FROM || "";

global.api_smd = "https://api-smd-1.vercel.app";
global.scan = "https://secret-garden-43998-4daad95d4561.herokuapp.com/";

global.SESSION_ID =
  process.env.SESSION_ID ||
  "eyJub2lzZUtleSI6eyJwcml2YXRlIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiSVArRDBjajlFR3kvblRNRURHMjhoaGtHb0xDMVVGcnlPYUwwLzJsRDdHcz0ifSwicHVibGljIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiUHVkTFhRRU1CeXZwMzNueWJLYXUrS2VuUVdOdmd6azhneGNpVEJlUUFSZz0ifX0sInBhaXJpbmdFcGhlbWVyYWxLZXlQYWlyIjp7InByaXZhdGUiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiI4TXpSaGhOajM5YW0vN2pIcjVBK3ViNEhPY0dKUVZFVUZwOEg0OENoakZRPSJ9LCJwdWJsaWMiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiIxZnBDQmpVZUVPU2tMK1lvOHBaWWpsOHFwdTNsR0p3RS9hbSs4bHlGYms0PSJ9fSwic2lnbmVkSWRlbnRpdHlLZXkiOnsicHJpdmF0ZSI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6IkNOeU1Cam1RbUhYK2UvNlpZaEQxRDZyWG9JYXNJUGF0cEZ2dWlwSmFBMW89In0sInB1YmxpYyI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6Im5mV212SXJHcVl4a1VKc0gxZW90cjJJWWxsLzRyQW1PZEl4Q25NM0tvRTQ9In19LCJzaWduZWRQcmVLZXkiOnsia2V5UGFpciI6eyJwcml2YXRlIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiME1RVjNxZ2dsSTIveUdkd2E5T2N6bE8yelczWnIybFB3Y0pBcUg4S05VVT0ifSwicHVibGljIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiUEU0K2JocXhLWEJicTVrdTIvT3ZjL0FDSnFXODB3TEdMYS9WQnM0VmNYST0ifX0sInNpZ25hdHVyZSI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6IjRUdkEwelgvUk5qYXc4UC82U3JENVlpajVVdUZCaEViVUs2dExIZExOMzVNV3pIV1lsTXpFVkUrbm5sVE1BR1FhVXRnc1ZGek80U3Q5c0JtT2FaRWhRPT0ifSwia2V5SWQiOjF9LCJyZWdpc3RyYXRpb25JZCI6OTAsImFkdlNlY3JldEtleSI6Ikdzb2wxeEcvS05UV2dmdXdqS3FsTi80MTJIcTN2UXEvUnZId0hQWWhRbVU9IiwicHJvY2Vzc2VkSGlzdG9yeU1lc3NhZ2VzIjpbeyJrZXkiOnsicmVtb3RlSmlkIjoiOTQ3MDE1MTU2MDlAcy53aGF0c2FwcC5uZXQiLCJmcm9tTWUiOnRydWUsImlkIjoiRTBFQUM5N0MwQkM1N0RGREM3NTk1NjNDRDc2MUE4NzcifSwibWVzc2FnZVRpbWVzdGFtcCI6MTcyMjUzNzM1NX1dLCJuZXh0UHJlS2V5SWQiOjMxLCJmaXJzdFVudXBsb2FkZWRQcmVLZXlJZCI6MzEsImFjY291bnRTeW5jQ291bnRlciI6MSwiYWNjb3VudFNldHRpbmdzIjp7InVuYXJjaGl2ZUNoYXRzIjpmYWxzZX0sImRldmljZUlkIjoialJiUzV0TzZSMkc4ckgxNnJGYnl1ZyIsInBob25lSWQiOiJkZjcyMDI5My04MGE2LTRhYWItOGZlNy00ZmY4NTExYWJhZTMiLCJpZGVudGl0eUlkIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiSFZPQ2ZxT1JxRXEwZG43OWhTb3ZwVlovZXJrPSJ9LCJyZWdpc3RlcmVkIjp0cnVlLCJiYWNrdXBUb2tlbiI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6IkxBYWtOczVUbEIwUndic0xHMEJ0RkVjZGZZUT0ifSwicmVnaXN0cmF0aW9uIjp7fSwicGFpcmluZ0NvZGUiOiI3UVpWNlRCNyIsIm1lIjp7ImlkIjoiOTQ3MDE1MTU2MDk6MzZAcy53aGF0c2FwcC5uZXQiLCJuYW1lIjoiSEFOU0EgREVXTUlOQSJ9LCJhY2NvdW50Ijp7ImRldGFpbHMiOiJDS3FHMXRVQ0VQdXFyN1VHR0FzZ0FDZ0EiLCJhY2NvdW50U2lnbmF0dXJlS2V5IjoiRkZVT1F4OFdjeldRUExUSUZXVVluU3dMeFppeGF5SzYyZWhkdjhIbHpSVT0iLCJhY2NvdW50U2lnbmF0dXJlIjoiSXcxdHhmTUFmVFRuMkYrV1A0QXNIM09jMjVLZ01JOVV0b2htSVhzN1E4MjVKcnUyMnVhenV5d1BBK1ZuU3dSRENqeFZXcVZ3WmZWMkVKUG5WdFZ6REE9PSIsImRldmljZVNpZ25hdHVyZSI6ImE3cDRCZ0FPb2dUSS9MUm5iWlpWWVQxclZzcHF2VmlPNVNSNU1OZE9PbVp3VE93OUFHM0c0SHdZSmJ6Wjl6S2ZYdnNQSjA0Q1JObWd2SHRocUdMNWdnPT0ifSwic2lnbmFsSWRlbnRpdGllcyI6W3siaWRlbnRpZmllciI6eyJuYW1lIjoiOTQ3MDE1MTU2MDk6MzZAcy53aGF0c2FwcC5uZXQiLCJkZXZpY2VJZCI6MH0sImlkZW50aWZpZXJLZXkiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiJCUlJWRGtNZkZuTTFrRHkweUJWbEdKMHNDOFdZc1dzaXV0bm9YYi9CNWMwViJ9fV0sInBsYXRmb3JtIjoiYW5kcm9pZCIsImxhc3RBY2NvdW50U3luY1RpbWVzdGFtcCI6MTcyMjUzNzM1MiwibXlBcHBTdGF0ZUtleUlkIjoiQUFBQUFNM2sifQ=="
module.exports = {
  menu: process.env.MENU || "2",
  HANDLERS: process.env.PREFIX || ".",
  BRANCH: process.env.BRANCH || "main",
  VERSION: process.env.VERSION || "1.0.0",
  caption: process.env.CAPTION || "`QUEEN_ANITA-V2™`",
  author: process.env.PACK_AUTHER || "QUEEN_ANITA-V2",
  packname: process.env.PACK_NAME || "A N I T A",
  botname: process.env.BOT_NAME || "QUEEN_ANITA-V2",
  ownername: process.env.OWNER_NAME || "HANSA DEWMINA",
  errorChat: process.env.ERROR_CHAT || "",
  KOYEB_API: process.env.KOYEB_API || "false",
  REMOVE_BG_KEY: process.env.REMOVE_BG_KEY || "",
  OPENAI_API_KEY: process.env.OPENAI_API_KEY || "",
  HEROKU_API_KEY: process.env.HEROKU_API_KEY || "",
  HEROKU_APP_NAME: process.env.HEROKU_APP_NAME || "",
  antilink_values: process.env.ANTILINK_VALUES || "all",
  HEROKU: process.env.HEROKU_APP_NAME && process.env.HEROKU_API_KEY,
  aitts_Voice_Id: process.env.AITTS_ID || "37",
  ELEVENLAB_API_KEY: process.env.ELEVENLAB_API_KEY || "",
  WORKTYPE: process.env.WORKTYPE || process.env.MODE || "public",
  LANG: (process.env.THEME || "A N I T A").toUpperCase(),
};
global.rank = "updated";
global.isMongodb = false;
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`Update'${__filename}'`);
  delete require.cache[file];
  require(file);
});
